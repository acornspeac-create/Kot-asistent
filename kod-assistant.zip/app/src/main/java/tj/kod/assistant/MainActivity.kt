package tj.kod.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var heard by mutableStateOf("Нажми микрофон и скажи команду")
    private var reply by mutableStateOf("")

    private val speechLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val text = result.data
                    ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    ?.firstOrNull()
                    .orEmpty()
                if (text.isNotBlank()) {
                    heard = text
                    handleCommand(text)
                }
            }
        }

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening() else {
                reply = "Нужен доступ к микрофону."
                speak(reply)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("КОД", style = MaterialTheme.typography.displayMedium)
                        Spacer(Modifier.height(24.dp))
                        Text(heard)
                        if (reply.isNotBlank()) {
                            Spacer(Modifier.height(12.dp))
                            Text(reply, style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(Modifier.height(32.dp))
                        Button(
                            onClick = { ensureMicAndListen() },
                            modifier = Modifier.fillMaxWidth().height(64.dp)
                        ) {
                            Text("Говорить")
                        }
                    }
                }
            }
        }
    }

    private fun ensureMicAndListen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Говори")
        }
        speechLauncher.launch(intent)
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale.getDefault())
        when {
            ("код" in command && ("ты здесь" in command || "здесь" == command.trim())) -> {
                reply = "Да, я здесь."
                speak(reply)
            }
            "открой камеру" in command || "камера" == command.trim() -> {
                reply = "Открываю камеру."
                speak(reply)
                startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            }
            "открой настройки" in command || "настройки" == command.trim() -> {
                reply = "Открываю настройки."
                speak(reply)
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
            "открой браузер" in command || "браузер" == command.trim() -> {
                reply = "Открываю браузер."
                speak(reply)
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
            }
            else -> {
                reply = "Я услышал: $raw. Это первая версия. Следующим шагом подключим полноценный ИИ."
                speak(reply)
            }
        }
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kod")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("ru", "RU")
        }
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
